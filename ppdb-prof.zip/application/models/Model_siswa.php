<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Model_siswa extends CI_Model{

   function statistik_data()
   {

   }

}
?>
